package hust.soict.dsai.test.disc;
import hust.soict.dsai.aims.media.DigitalVideoDisc;

public class dvdWrapper {
	DigitalVideoDisc c;
	public dvdWrapper(DigitalVideoDisc c) {
		this.c = c;
	}
}
